﻿namespace ASPFormValidation.Model
{
    public enum KnowledgeSource
    {
        Email,
        Web,
        Známý,
        Časopis,
        Nevím
    }
}
