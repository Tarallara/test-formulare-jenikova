using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ASPFormValidation.Pages
{
    public class SuccessModel : PageModel
    {
        public bool Successful { get; set; } = true;
        public string Firstname { get; set; }
        public string Email { get; set; }
        public void OnGet(string firstname, string email)
        {
            if (String.IsNullOrEmpty(firstname) || String.IsNullOrEmpty(email))
            {
                Successful = false;
            }
            else
            {
                Successful = true;
                Firstname = firstname;
                Email = email;
            }
        }
    }
}
