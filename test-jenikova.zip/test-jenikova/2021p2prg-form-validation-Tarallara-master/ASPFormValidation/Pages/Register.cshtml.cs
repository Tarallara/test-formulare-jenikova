using ASPFormValidation.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel.DataAnnotations;

namespace ASPFormValidation.Pages
{
    public class RegisterModel : PageModel
    {
        [BindProperty]
        [Required(ErrorMessage = "Jm�no mus� b�t vypln�no.")]
        [RegularExpression("^[a-zA-Z]*$", ErrorMessage = "Mus� obsahovat jenom p�smena")]
        public string Firstname { get; set; } = "";

        [BindProperty]
        [Required(ErrorMessage = "E-mail mus� b�t vypln�n.")]
        [EmailAddress(ErrorMessage = "E-mail mus� b�t vypln�n.")]
        public string Email { get; set; } = "X@X.X";



        [BindProperty]
        [Required(ErrorMessage = "Vyberte si po�et odm�n.")]
        public string Odmena { get; set; } = "";

        [BindProperty]
        [Required(ErrorMessage = "Vypl�te heslo.")]
        [MinLength(6, ErrorMessage = "Heslo mus� m�t alespo� 6 znak�.")]
        public string Password { get; set; } = "";

        [BindProperty]
        [Required(ErrorMessage = "Vypl�te heslo pro ov��en�.")]
        [MinLength(6, ErrorMessage = "Heslo mus� m�t alespo� 6 znak�.")]
        [Compare(nameof(Password), ErrorMessage = "Ob� hesla mus� b�t stejn�.")]
        public string Password_again { get; set; } = "";



        [BindProperty]
        [Display(Name = "Souhlas se zpracov�n�m informac�")]
        [Range(typeof(bool), "true", "true", ErrorMessage = "Mus�te souhlasit se zpracov�n�m informac�!")]
        public bool Check { get; set; } = false;


        [BindProperty]
        [Range(0, 3)]
        [Required(ErrorMessage = "Po�et odm�n mus� b�t ��slo mezi 0 a 3.")]
        public int Number { get; set; } = 0;

        [BindProperty]
        [Required(ErrorMessage = "Pobo�ka mus� b�t vypln�na.")]
        public string Pobocka { get; set; }

        public List<SelectListItem> Options = new List<SelectListItem>
                {
                  new SelectListItem { Value = "Liberec", Text = "Liberec"},
                  new SelectListItem { Value = "Praha", Text = "Praha"},
                  new SelectListItem { Value = "Plze�", Text = "Plze�" }
                };
        

        public KnowledgeSource Source { get; set; }




        public void OnGet()
        {

        }


        public ActionResult OnPost()
        {
            if (!ModelState.IsValid) 
            {
                return Page();
            }
            return RedirectToPage("Success", new { Firstname = Firstname, Email = Email});
        }
    }
}

